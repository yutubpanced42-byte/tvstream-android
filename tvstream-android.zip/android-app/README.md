# 📱 TV Stream International — Android APK

Aplikasi Android (WebView) untuk menonton siaran TV internasional live (HLS).
Dibuat oleh **BINTANG**.

- ✅ **Tidak butuh server/Termux** — stream diputar langsung di aplikasi.
- ✅ **hls.js dibundel offline** di dalam APK (tidak butuh CDN).
- ✅ Pilihan **channel** + **kualitas** (Auto/Full HD/HD/SD/Low).
- ✅ Channel: CGTN, DW English, DW Arabic, TVRI World.

> Catatan teknis: keempat stream sudah mengirim header `Access-Control-Allow-Origin: *`,
> jadi WebView bisa memutarnya langsung tanpa proxy.

---

## 🚀 Cara Mendapatkan File APK

Ada **3 cara**. Pilih yang paling cocok.

### ⭐ Cara 1 — Build otomatis di cloud (TANPA PC, paling mudah)
Pakai **GitHub Actions** — APK dikompilasi di server GitHub, kamu tinggal unduh.

1. Buat repo baru di GitHub, lalu upload **seluruh isi folder `android-app/`** ke repo itu
   (bisa lewat web GitHub: "Add file" → "Upload files", atau `git push`).
2. Buka tab **Actions** di repo → workflow **"Build APK"** akan jalan otomatis.
   (Kalau belum jalan, klik workflow → **Run workflow**.)
3. Tunggu ±3–5 menit sampai centang hijau ✅.
4. Klik workflow yang selesai → bagian **Artifacts** → unduh **`TVStreamIntl-debug-apk`**.
5. Ekstrak ZIP-nya → dapat file **`app-debug.apk`**.
6. Kirim ke HP, lalu install (lihat bagian "Cara Install" di bawah).

> 💡 Mau APK muncul di halaman Releases? Buat tag:
> `git tag v1.0 && git push origin v1.0` → workflow otomatis membuat Release berisi APK.

### Cara 2 — Build di komputer (Android Studio)
1. Install [Android Studio](https://developer.android.com/studio).
2. **Open** folder `android-app/` ini.
3. Tunggu Gradle sync selesai.
4. Menu **Build → Build Bundle(s)/APK(s) → Build APK(s)**.
5. APK ada di: `app/build/outputs/apk/debug/app-debug.apk`.

### Cara 3 — Build via command line
Butuh JDK 17 + Android SDK terpasang (`ANDROID_HOME` di-set).
```bash
cd android-app
./gradlew assembleDebug
# hasil: app/build/outputs/apk/debug/app-debug.apk
```

---

## 📲 Cara Install APK di HP
1. Pindahkan `app-debug.apk` ke HP.
2. Buka file → Android akan minta izin **"Install dari sumber tidak dikenal"** → izinkan.
3. Install → buka aplikasi **TV Stream Intl**.
4. Pilih channel → tekan **▶ Putar**. Butuh koneksi internet.

---

## 🗂️ Struktur Project
```
android-app/
├── .github/workflows/build-apk.yml   # CI: kompilasi APK otomatis
├── app/
│   ├── build.gradle                  # konfigurasi modul app
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── assets/
│       │   ├── index.html            # UI player
│       │   └── hls.min.js            # hls.js (offline, dibundel)
│       ├── java/com/bintang/tvstream/MainActivity.java
│       └── res/
│           ├── mipmap-*/ic_launcher.png   # ikon (semua densitas)
│           └── values/strings.xml
├── build.gradle
├── settings.gradle
├── gradle.properties
├── gradle/wrapper/...                # Gradle wrapper
├── gradlew / gradlew.bat
└── README.md
```

---

## ⚙️ Spesifikasi
| Item | Nilai |
|------|-------|
| Package | `com.bintang.tvstream` |
| Min SDK | 21 (Android 5.0) |
| Target SDK | 34 (Android 14) |
| Bahasa | Java + WebView + hls.js |
| Output | `app-debug.apk` (bisa langsung diinstall) |

---

## ❓ Troubleshooting
| Masalah | Solusi |
|---------|--------|
| Video tidak jalan | Pastikan HP terhubung internet; coba kualitas lebih rendah |
| "App not installed" | Hapus versi lama dulu, atau aktifkan install sumber tak dikenal |
| Actions gagal build | Buka log di tab Actions; biasanya cukup klik **Re-run jobs** |
| Channel tertentu blank | Sebagian stream butuh region tertentu / kadang offline sementara |

— **BINTANG**
