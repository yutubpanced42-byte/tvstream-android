# 📋 Panduan Build APK via GitHub Actions

Membuat file `.apk` **tanpa PC & tanpa Android Studio** — dikompilasi di cloud GitHub.

> 💡 Versi visual bergaya screenshot ada di **`PANDUAN-GITHUB-ACTIONS.html`** (buka di browser / preview).

---

## Langkah 1 — Akun GitHub
Buka **github.com** → daftar (gratis). Sudah punya? Lewati.

## Langkah 2 — Buat Repository
1. Klik **+** (kanan atas) → **New repository**.
2. Nama: `tvstream-android` (bebas).
3. Visibility: **Public** ✅ (agar Actions gratis tanpa batas).
4. **Jangan** centang "Add a README / .gitignore".
5. Klik **Create repository**.

## Langkah 3 — Upload File Project
1. Di repo baru, klik **Add file → Upload files** (atau link "uploading an existing file").
2. Extract `tvstream-android.zip`, buka folder `android-app`, seleksi **SEMUA isinya** (Ctrl+A), drag ke kotak upload.
3. Klik **Commit changes**.

> ⚠️ **PENTING:** Upload **ISI** folder `android-app` (file `build.gradle`, `settings.gradle`, folder `app`, `.github`, `gradle`, `gradlew`, dll) — **bukan** folder `android-app`-nya sendiri.
> File `.github/workflows/build-apk.yml` harus berada di **root repo**.
> Folder `.github` kadang tersembunyi — pastikan ikut ter-upload.

## Langkah 4 — Actions Membangun APK Otomatis
1. Buka tab **Actions**.
2. Workflow **"Build APK"** jalan otomatis (±3-5 menit).
3. Tunggu sampai **centang hijau ✅**.

> 🔄 Tidak jalan otomatis? Klik workflow **"Build APK"** → **Run workflow** → branch `main` → **Run workflow**.
> ❌ Gagal (silang merah)? Klik run → lihat log → **Re-run jobs** (biasanya cuma jaringan sementara).

## Langkah 5 — Unduh APK
1. Klik run yang **✅ sukses**.
2. Scroll ke bagian **Artifacts**.
3. Klik **`TVStreamIntl-debug-apk`** → terunduh sebagai `.zip`.
4. **Extract** → dapat file **`app-debug.apk`**.

> 📱 Bisa diunduh langsung dari browser HP juga.

## Langkah 6 — Install di HP
1. Pindahkan `app-debug.apk` ke HP.
2. Buka file → izinkan **"Install dari sumber tidak dikenal"**.
3. **Install** → buka aplikasi **📡 TV Stream Intl**.
4. Pilih channel → **▶ Putar** (butuh internet).

## Langkah 7 (Opsional) — Rilis via Tag
Agar APK muncul di halaman **Releases** (mudah dibagikan):
```bash
git tag v1.0
git push origin v1.0
```
Workflow otomatis membuat **Release** berisi APK. Tanpa Git? Buat lewat web: tab **Releases → Draft a new release → tag v1.0 → Publish**.

---

## ❓ Troubleshooting Cepat
| Masalah | Solusi |
|---------|--------|
| Workflow tidak muncul | Pastikan `.github/workflows/build-apk.yml` ada di root repo |
| Build gagal ❌ | Buka log di tab Actions → **Re-run jobs** |
| Tidak ada Artifacts | Build harus selesai **sukses** dulu (✅) |
| "App not installed" | Hapus versi lama / aktifkan sumber tak dikenal |
| Video tidak jalan | Cek koneksi internet HP; coba kualitas lebih rendah |

— **BINTANG**
